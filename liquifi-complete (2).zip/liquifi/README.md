# LiquiFi — CIBIL Score Automation Platform

A production-ready fintech platform that automates CIBIL score retrieval via UrbanMoney.

## Architecture

```
User → React Frontend → Spring Boot API → Redis Queue → Selenium Worker → UrbanMoney
                                                                        ↓
                                                              Supabase PostgreSQL
```

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Frontend    | React 18 + TypeScript + Vite        |
| Backend     | Java 21 + Spring Boot 3.2           |
| Automation  | Selenium Java 4 + ChromeDriver      |
| Database    | Supabase (PostgreSQL)               |
| Queue       | Redis 7                             |
| Reverse Proxy | NGINX                             |
| Hosting     | Ubuntu VPS + Docker                 |

## Quick Start

### 1. Setup environment
```bash
cp .env.example .env
# Fill in your Supabase and Redis credentials
```

### 2. Run DB migrations
```bash
# Flyway auto-runs migrations on Spring Boot start
# Or manually apply: supabase/migrations/*.sql
```

### 3. Start with Docker Compose
```bash
cd infra/docker
docker compose up -d
```

### 4. Build Frontend
```bash
cd frontend
npm install && npm run build
```

## Business Flow

1. User fills CIBIL form on LiquiFi
2. User accepts TUCIBIL consent
3. Backend records consent log + creates session
4. Job published to Redis queue
5. Selenium worker picks up job, opens UrbanMoney in headless Chrome
6. Worker fills the form, UrbanMoney sends OTP to user's mobile
7. User enters OTP on LiquiFi frontend
8. Backend relays OTP via Redis to Selenium worker
9. Worker submits OTP on UrbanMoney
10. Worker extracts credit score, summary, loan eligibility
11. Results stored in Supabase
12. Frontend displays results

## Key Security Properties

- OTP is **never stored in DB** — relayed through Redis with 5-minute TTL
- Consent is recorded as an **immutable audit log**
- Each user gets a **separate browser instance** — no session sharing
- Sessions **auto-expire** after 30 minutes
- All API endpoints rate-limited via NGINX

## Project Structure

```
liquifi/
├── frontend/      # React + TypeScript + Vite
├── backend/       # Spring Boot API
├── automation/    # Selenium worker
├── infra/         # NGINX, Docker, scripts
└── supabase/      # SQL migrations + seed
```
