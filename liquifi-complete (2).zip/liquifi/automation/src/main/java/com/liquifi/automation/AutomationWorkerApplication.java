package com.liquifi.automation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class AutomationWorkerApplication {

    public static void main(String[] args) {
        SpringApplication.run(AutomationWorkerApplication.class, args);
    }
}
