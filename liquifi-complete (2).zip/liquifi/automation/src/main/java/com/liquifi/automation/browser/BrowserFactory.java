package com.liquifi.automation.browser;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.chrome.ChromeOptions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class BrowserFactory {

    private final ChromeOptions chromeOptions;

    @Value("${liquifi.automation.page-load-timeout:30}")
    private int pageLoadTimeout;

    @Value("${liquifi.automation.implicit-wait:10}")
    private int implicitWait;

    /**
     * Creates a fresh, isolated browser session for each user automation request.
     */
    public BrowserSession createSession(String sessionId) {
        log.info("Creating new browser session for sessionId={}", sessionId);
        return new BrowserSession(sessionId, chromeOptions, pageLoadTimeout, implicitWait);
    }
}
