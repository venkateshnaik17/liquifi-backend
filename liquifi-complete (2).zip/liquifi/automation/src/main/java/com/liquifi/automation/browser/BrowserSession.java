package com.liquifi.automation.browser;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

/**
 * Encapsulates a dedicated Chrome browser instance for a single CIBIL session.
 * One BrowserSession per user request — never shared between sessions.
 */
@Slf4j
@Getter
public class BrowserSession implements AutoCloseable {

    private final String sessionId;
    private final WebDriver driver;

    public BrowserSession(String sessionId, ChromeOptions options,
                          int pageLoadTimeout, int implicitWait) {
        this.sessionId = sessionId;
        this.driver = new ChromeDriver(options);
        this.driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(pageLoadTimeout));
        this.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(implicitWait));
        this.driver.manage().window().maximize();
        log.info("BrowserSession created for sessionId={}", sessionId);
    }

    @Override
    public void close() {
        try {
            if (driver != null) {
                driver.quit();
                log.info("BrowserSession closed for sessionId={}", sessionId);
            }
        } catch (Exception e) {
            log.warn("Error closing browser for sessionId={}: {}", sessionId, e.getMessage());
        }
    }
}
