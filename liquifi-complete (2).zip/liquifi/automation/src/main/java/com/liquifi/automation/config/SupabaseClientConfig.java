package com.liquifi.automation.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Supabase is accessed directly via JDBC (PostgreSQL driver).
 * No additional client library needed.
 */
@Configuration
public class SupabaseClientConfig {

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    public String getJdbcUrl() {
        return jdbcUrl;
    }
}
