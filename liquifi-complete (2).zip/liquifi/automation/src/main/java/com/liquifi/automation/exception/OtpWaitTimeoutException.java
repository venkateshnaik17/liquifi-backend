package com.liquifi.automation.exception;

public class OtpWaitTimeoutException extends RuntimeException {
    public OtpWaitTimeoutException(String sessionId) {
        super("Timed out waiting for OTP for session: " + sessionId);
    }
}
