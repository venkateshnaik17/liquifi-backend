package com.liquifi.automation.extractor;

import com.liquifi.automation.pages.UrbanMoneyCibilResultPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class CibilScoreExtractor {

    /**
     * Extracts credit score and score band from the result page.
     * @return Map with keys: score (Integer), scoreBand (String), scoreAsOfDate (LocalDate)
     */
    public Map<String, Object> extract(UrbanMoneyCibilResultPage page) {
        Map<String, Object> result = new HashMap<>();

        try {
            String rawScore = page.extractCreditScore();
            if (rawScore != null && !rawScore.isEmpty()) {
                int score = Integer.parseInt(rawScore.trim());
                result.put("score", score);
                result.put("scoreBand", determineBand(score));
                log.info("Extracted credit score: {}", score);
            } else {
                log.warn("Credit score not found on page");
            }
        } catch (NumberFormatException e) {
            log.error("Failed to parse credit score to integer: {}", e.getMessage());
        }

        String band = page.extractScoreBand();
        if (band != null && !band.isEmpty()) {
            result.put("scoreBand", normalizeScoreBand(band));
        }

        result.put("scoreAsOfDate", LocalDate.now());
        return result;
    }

    private String determineBand(int score) {
        if (score >= 750) return "EXCELLENT";
        if (score >= 700) return "GOOD";
        if (score >= 650) return "FAIR";
        return "POOR";
    }

    private String normalizeScoreBand(String raw) {
        String upper = raw.toUpperCase();
        if (upper.contains("EXCELLENT") || upper.contains("VERY GOOD")) return "EXCELLENT";
        if (upper.contains("GOOD"))    return "GOOD";
        if (upper.contains("FAIR") || upper.contains("AVERAGE")) return "FAIR";
        if (upper.contains("POOR") || upper.contains("BAD"))     return "POOR";
        return upper.trim();
    }
}
