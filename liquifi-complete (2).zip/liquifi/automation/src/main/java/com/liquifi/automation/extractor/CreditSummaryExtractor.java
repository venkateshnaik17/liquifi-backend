package com.liquifi.automation.extractor;

import com.liquifi.automation.pages.UrbanMoneyCibilResultPage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Slf4j
public class CreditSummaryExtractor {

    /**
     * Extracts credit summary statistics from the result page.
     * Returns a map suitable for JSONB storage.
     */
    public Map<String, Object> extract(UrbanMoneyCibilResultPage page) {
        Map<String, Object> summary = new HashMap<>();

        summary.put("totalAccounts",    parseIntSafe(page.extractTotalAccounts()));
        summary.put("activeAccounts",   parseIntSafe(page.extractActiveAccounts()));
        summary.put("closedAccounts",   parseIntSafe(page.extractClosedAccounts()));
        summary.put("overdueAccounts",  parseIntSafe(page.extractOverdueAccounts()));
        summary.put("totalCreditLimit", parseAmountSafe(page.extractCreditLimit()));
        summary.put("totalBalance",     parseAmountSafe(page.extractTotalBalance()));

        log.info("Extracted credit summary: accounts={}, active={}, overdue={}",
            summary.get("totalAccounts"),
            summary.get("activeAccounts"),
            summary.get("overdueAccounts"));

        return summary;
    }

    private Integer parseIntSafe(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            return Integer.parseInt(raw.replaceAll("[^0-9]", "").trim());
        } catch (NumberFormatException e) {
            log.debug("Could not parse integer from: {}", raw);
            return null;
        }
    }

    private Long parseAmountSafe(String raw) {
        if (raw == null || raw.isBlank()) return null;
        try {
            // Handles formats like ₹1,20,000 or Rs. 1,20,000
            String cleaned = raw.replaceAll("[^0-9]", "").trim();
            return cleaned.isEmpty() ? null : Long.parseLong(cleaned);
        } catch (NumberFormatException e) {
            log.debug("Could not parse amount from: {}", raw);
            return null;
        }
    }
}
