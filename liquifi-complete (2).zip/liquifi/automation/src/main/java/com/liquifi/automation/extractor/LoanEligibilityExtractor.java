package com.liquifi.automation.extractor;

import com.liquifi.automation.pages.UrbanMoneyCibilResultPage;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebElement;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class LoanEligibilityExtractor {

    /**
     * Extracts loan eligibility cards from the result page.
     * Each card becomes a map with loanType, maxAmount, interestRate, tenure, eligibilityStatus.
     */
    public List<Map<String, Object>> extract(UrbanMoneyCibilResultPage page) {
        List<Map<String, Object>> eligibilityList = new ArrayList<>();

        try {
            List<WebElement> cards = page.extractLoanCards();
            log.info("Found {} loan eligibility cards", cards.size());

            for (WebElement card : cards) {
                Map<String, Object> loan = new HashMap<>();
                try {
                    String cardText = card.getText();
                    loan.put("rawText", cardText);
                    loan.put("loanType",          extractLoanType(cardText));
                    loan.put("maxAmount",          extractAmount(cardText));
                    loan.put("interestRate",       extractInterestRate(cardText));
                    loan.put("tenure",             extractTenure(cardText));
                    loan.put("eligibilityStatus",  extractEligibilityStatus(cardText));
                    eligibilityList.add(loan);
                } catch (Exception e) {
                    log.warn("Error parsing loan card: {}", e.getMessage());
                }
            }
        } catch (Exception e) {
            log.error("Failed to extract loan eligibility: {}", e.getMessage());
        }

        if (eligibilityList.isEmpty()) {
            log.warn("No loan eligibility data found — returning empty list");
        }

        return eligibilityList;
    }

    private String extractLoanType(String text) {
        String upper = text.toUpperCase();
        if (upper.contains("HOME"))     return "Home Loan";
        if (upper.contains("PERSONAL")) return "Personal Loan";
        if (upper.contains("BUSINESS")) return "Business Loan";
        if (upper.contains("CAR") || upper.contains("AUTO")) return "Car Loan";
        if (upper.contains("EDUCATION")) return "Education Loan";
        return "Other";
    }

    private String extractAmount(String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("(?i)(upto|up to|max)?\\s*[₹Rs.]*\\s*([\\d,]+(?:\\s*(?:lakh|lakhs|cr|crore))?)")
            .matcher(text);
        return m.find() ? m.group(0).trim() : null;
    }

    private String extractInterestRate(String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("([\\d.]+)\\s*%\\s*(?:p\\.a\\.?|per annum)?")
            .matcher(text);
        return m.find() ? m.group(0).trim() : null;
    }

    private String extractTenure(String text) {
        java.util.regex.Matcher m = java.util.regex.Pattern
            .compile("([\\d]+)\\s*(?:months?|years?|yrs?)")
            .matcher(text);
        return m.find() ? m.group(0).trim() : null;
    }

    private String extractEligibilityStatus(String text) {
        String upper = text.toUpperCase();
        if (upper.contains("ELIGIBLE") && !upper.contains("NOT")) return "ELIGIBLE";
        if (upper.contains("NOT ELIGIBLE")) return "NOT_ELIGIBLE";
        if (upper.contains("PRE-APPROVED") || upper.contains("PRE APPROVED")) return "PRE_APPROVED";
        return "UNKNOWN";
    }
}
