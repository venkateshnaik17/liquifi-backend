package com.liquifi.automation.pages;

import com.liquifi.automation.util.WaitUtil;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

@Slf4j
public abstract class BasePage {

    protected final WebDriver driver;
    protected final WaitUtil waitUtil;
    protected static final int DEFAULT_WAIT = 20;

    protected BasePage(WebDriver driver, WaitUtil waitUtil) {
        this.driver = driver;
        this.waitUtil = waitUtil;
        PageFactory.initElements(driver, this);
    }

    protected void click(By locator) {
        WebElement el = waitUtil.waitForClickable(driver, locator, DEFAULT_WAIT);
        el.click();
    }

    protected void type(By locator, String text) {
        WebElement el = waitUtil.waitForVisible(driver, locator, DEFAULT_WAIT);
        el.clear();
        el.sendKeys(text);
    }

    protected void typeSlowly(By locator, String text) {
        WebElement el = waitUtil.waitForVisible(driver, locator, DEFAULT_WAIT);
        el.clear();
        for (char c : text.toCharArray()) {
            el.sendKeys(String.valueOf(c));
            waitUtil.sleep(50);
        }
    }

    protected String getText(By locator) {
        return waitUtil.waitForVisible(driver, locator, DEFAULT_WAIT).getText().trim();
    }

    protected void scrollIntoView(By locator) {
        WebElement el = driver.findElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);
        waitUtil.sleep(300);
    }

    protected void jsClick(By locator) {
        WebElement el = driver.findElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    protected boolean isPresent(By locator) {
        return !driver.findElements(locator).isEmpty();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }
}
