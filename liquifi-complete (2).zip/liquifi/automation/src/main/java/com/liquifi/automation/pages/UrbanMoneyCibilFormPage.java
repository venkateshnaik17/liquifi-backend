package com.liquifi.automation.pages;

import com.liquifi.automation.util.WaitUtil;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Slf4j
public class UrbanMoneyCibilFormPage extends BasePage {

    // Form field locators — based on UrbanMoney DOM structure
    private final By fullNameInput   = By.xpath("//input[@name='fullName' or @placeholder='Full Name' or @id='fullName']");
    private final By dobDaySelect    = By.xpath("//select[@name='day' or @id='day']");
    private final By dobMonthSelect  = By.xpath("//select[@name='month' or @id='month']");
    private final By dobYearSelect   = By.xpath("//select[@name='year' or @id='year']");
    private final By dobInput        = By.xpath("//input[@name='dob' or @id='dob' or @type='date']");
    private final By mobileInput     = By.xpath("//input[@name='mobile' or @name='mobileNumber' or @placeholder='Mobile Number']");
    private final By emailInput      = By.xpath("//input[@type='email' or @name='email' or @placeholder='Email']");
    private final By panInput        = By.xpath("//input[@name='pan' or @name='panCard' or @placeholder='PAN']");
    private final By consentCheckbox = By.xpath("//input[@type='checkbox'][contains(@name,'consent') or contains(@id,'consent')]");
    private final By submitBtn       = By.xpath("//button[@type='submit' or contains(text(),'Get Score') or contains(text(),'Submit') or contains(text(),'Check Score')]");

    public UrbanMoneyCibilFormPage(WebDriver driver, WaitUtil waitUtil) {
        super(driver, waitUtil);
    }

    public void fillFullName(String fullName) {
        typeSlowly(fullNameInput, fullName);
        log.info("Filled full name");
    }

    public void fillDob(LocalDate dob) {
        try {
            // Try date dropdowns first
            if (isPresent(dobDaySelect)) {
                new Select(driver.findElement(dobDaySelect)).selectByValue(String.valueOf(dob.getDayOfMonth()));
                new Select(driver.findElement(dobMonthSelect)).selectByValue(String.valueOf(dob.getMonthValue()));
                new Select(driver.findElement(dobYearSelect)).selectByValue(String.valueOf(dob.getYear()));
                log.info("Filled DOB via dropdowns");
            } else if (isPresent(dobInput)) {
                // Try date input field
                String formatted = dob.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                typeSlowly(dobInput, formatted);
                log.info("Filled DOB via input field");
            }
        } catch (Exception e) {
            log.warn("DOB fill error, trying alternate method: {}", e.getMessage());
            String formatted = dob.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
            typeSlowly(dobInput, formatted);
        }
    }

    public void fillMobile(String mobile) {
        typeSlowly(mobileInput, mobile);
        log.info("Filled mobile number");
    }

    public void fillEmail(String email) {
        typeSlowly(emailInput, email);
        log.info("Filled email");
    }

    public void fillPan(String pan) {
        typeSlowly(panInput, pan.toUpperCase());
        log.info("Filled PAN card");
    }

    public void acceptConsent() {
        try {
            if (isPresent(consentCheckbox)) {
                var checkbox = driver.findElement(consentCheckbox);
                if (!checkbox.isSelected()) {
                    jsClick(consentCheckbox);
                    log.info("Accepted consent checkbox");
                }
            }
        } catch (Exception e) {
            log.warn("Could not find consent checkbox: {}", e.getMessage());
        }
    }

    public void submit() {
        scrollIntoView(submitBtn);
        waitUtil.sleep(500);
        click(submitBtn);
        log.info("Form submitted");
        waitUtil.sleep(3000);
    }

    public void fillAndSubmit(String fullName, LocalDate dob, String mobile,
                              String email, String pan) {
        fillFullName(fullName);
        waitUtil.sleep(300);
        fillDob(dob);
        waitUtil.sleep(300);
        fillMobile(mobile);
        waitUtil.sleep(300);
        fillEmail(email);
        waitUtil.sleep(300);
        fillPan(pan);
        waitUtil.sleep(300);
        acceptConsent();
        waitUtil.sleep(500);
        submit();
    }
}
