package com.liquifi.automation.pages;

import com.liquifi.automation.util.WaitUtil;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
public class UrbanMoneyCibilResultPage extends BasePage {

    // Credit Score locators
    private final By creditScoreValue     = By.xpath("//*[contains(@class,'credit-score') or contains(@class,'cibil-score') or contains(@class,'score-value')]//span[not(*)] | //div[@id='creditScore']");
    private final By scoreNumberFallback  = By.xpath("//*[contains(text(),'Your Score') or contains(text(),'CIBIL Score')]/following-sibling::*[1]");

    // Score band
    private final By scoreBandLabel       = By.xpath("//*[contains(@class,'score-label') or contains(@class,'score-band') or contains(@class,'score-rating')]");

    // Credit summary section
    private final By totalAccounts        = By.xpath("//*[contains(text(),'Total Accounts')]/following-sibling::*[1] | //*[@data-key='totalAccounts']");
    private final By activeAccounts       = By.xpath("//*[contains(text(),'Active')]/following-sibling::*[1]");
    private final By closedAccounts       = By.xpath("//*[contains(text(),'Closed')]/following-sibling::*[1]");
    private final By overdueAccounts      = By.xpath("//*[contains(text(),'Overdue')]/following-sibling::*[1]");
    private final By totalCreditLimit     = By.xpath("//*[contains(text(),'Credit Limit') or contains(text(),'Sanctioned')]/following-sibling::*[1]");
    private final By totalBalance         = By.xpath("//*[contains(text(),'Current Balance') or contains(text(),'Outstanding')]/following-sibling::*[1]");

    // Loan eligibility section
    private final By loanEligibilityCards = By.xpath("//*[contains(@class,'loan-card') or contains(@class,'eligibility-card') or contains(@class,'loan-offer')]");

    // Page readiness
    private final By resultPageReady      = By.xpath("//*[contains(@class,'credit-score') or contains(@class,'cibil-result') or contains(text(),'Your Credit Score')]");

    public UrbanMoneyCibilResultPage(WebDriver driver, WaitUtil waitUtil) {
        super(driver, waitUtil);
    }

    public boolean isResultPageLoaded() {
        try {
            waitUtil.waitForVisible(driver, resultPageReady, 30);
            log.info("CIBIL result page confirmed loaded");
            return true;
        } catch (Exception e) {
            log.warn("Result page readiness check failed: {}", e.getMessage());
            return false;
        }
    }

    public String extractCreditScore() {
        try {
            String score = getText(creditScoreValue);
            if (score.isEmpty()) {
                score = getText(scoreNumberFallback);
            }
            log.info("Extracted credit score: {}", score);
            return score.replaceAll("[^0-9]", "");
        } catch (Exception e) {
            log.error("Failed to extract credit score: {}", e.getMessage());
            return null;
        }
    }

    public String extractScoreBand() {
        try {
            return getText(scoreBandLabel);
        } catch (Exception e) {
            log.warn("Score band not found: {}", e.getMessage());
            return null;
        }
    }

    public String extractTotalAccounts()  { return extractSafe(totalAccounts); }
    public String extractActiveAccounts() { return extractSafe(activeAccounts); }
    public String extractClosedAccounts() { return extractSafe(closedAccounts); }
    public String extractOverdueAccounts(){ return extractSafe(overdueAccounts); }
    public String extractCreditLimit()    { return extractSafe(totalCreditLimit); }
    public String extractTotalBalance()   { return extractSafe(totalBalance); }

    public List<WebElement> extractLoanCards() {
        return driver.findElements(loanEligibilityCards);
    }

    public String getFullPageSource() {
        return driver.getPageSource();
    }

    private String extractSafe(By locator) {
        try {
            return getText(locator);
        } catch (Exception e) {
            log.debug("Element not found for locator {}: {}", locator, e.getMessage());
            return null;
        }
    }
}
