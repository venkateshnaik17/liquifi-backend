package com.liquifi.automation.pages;

import com.liquifi.automation.util.WaitUtil;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

@Slf4j
public class UrbanMoneyLandingPage extends BasePage {

    private static final String URL = "https://www.urbanmoney.com/credit-score";

    // Locators
    private final By checkScoreBtn    = By.xpath("//a[contains(text(),'Check Credit Score') or contains(text(),'Free Credit Score')]");
    private final By getCibilScoreBtn = By.xpath("//button[contains(text(),'Get CIBIL Score') or contains(@class,'cibil')]");

    public UrbanMoneyLandingPage(WebDriver driver, WaitUtil waitUtil) {
        super(driver, waitUtil);
    }

    public void open() {
        driver.get(URL);
        log.info("Opened UrbanMoney credit score page. Title={}", driver.getTitle());
        waitUtil.sleep(2000);
    }

    public void navigateToForm() {
        try {
            if (isPresent(checkScoreBtn)) {
                click(checkScoreBtn);
                log.info("Clicked 'Check Credit Score' button");
            } else if (isPresent(getCibilScoreBtn)) {
                click(getCibilScoreBtn);
                log.info("Clicked 'Get CIBIL Score' button");
            } else {
                // Direct navigation fallback
                driver.get("https://www.urbanmoney.com/credit-score/check-cibil-score");
                log.info("Direct navigation to CIBIL form page");
            }
        } catch (Exception e) {
            log.warn("Could not click landing CTA, attempting direct URL. Error: {}", e.getMessage());
            driver.get("https://www.urbanmoney.com/credit-score/check-cibil-score");
        }
        waitUtil.sleep(2000);
    }
}
