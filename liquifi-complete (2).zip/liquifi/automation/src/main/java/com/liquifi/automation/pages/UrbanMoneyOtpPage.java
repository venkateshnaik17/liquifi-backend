package com.liquifi.automation.pages;

import com.liquifi.automation.util.WaitUtil;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

@Slf4j
public class UrbanMoneyOtpPage extends BasePage {

    // OTP field locators — covers single input and split OTP boxes
    private final By otpSingleInput  = By.xpath("//input[@name='otp' or @id='otp' or @placeholder='OTP' or @placeholder='Enter OTP']");
    private final By otpBoxes        = By.xpath("//input[@maxlength='1' and @type='tel' or @type='number']");
    private final By resendOtpBtn    = By.xpath("//button[contains(text(),'Resend') or contains(text(),'resend')]");
    private final By verifyBtn       = By.xpath("//button[contains(text(),'Verify') or contains(text(),'Submit') or contains(text(),'Confirm')]");
    private final By otpErrorMsg     = By.xpath("//*[contains(@class,'error') and (contains(text(),'OTP') or contains(text(),'Invalid'))]");

    public UrbanMoneyOtpPage(WebDriver driver, WaitUtil waitUtil) {
        super(driver, waitUtil);
    }

    /**
     * Checks if the OTP input page is currently displayed.
     */
    public boolean isOtpPageVisible() {
        waitUtil.sleep(2000);
        return isPresent(otpSingleInput) || isPresent(otpBoxes);
    }

    /**
     * Enters OTP — handles both single input and split box layouts.
     */
    public void enterOtp(String otp) {
        List<WebElement> boxes = driver.findElements(otpBoxes);

        if (!boxes.isEmpty() && boxes.size() >= otp.length()) {
            // Split OTP boxes (one digit per box)
            log.info("Entering OTP into {} split boxes", boxes.size());
            for (int i = 0; i < otp.length() && i < boxes.size(); i++) {
                boxes.get(i).clear();
                boxes.get(i).sendKeys(String.valueOf(otp.charAt(i)));
                waitUtil.sleep(100);
            }
        } else if (isPresent(otpSingleInput)) {
            // Single OTP input field
            log.info("Entering OTP into single input field");
            typeSlowly(otpSingleInput, otp);
        } else {
            log.error("No OTP input field found on page");
            throw new RuntimeException("OTP input field not found on UrbanMoney page");
        }

        log.info("OTP entered successfully");
    }

    public void clickVerify() {
        if (isPresent(verifyBtn)) {
            click(verifyBtn);
            log.info("Clicked verify button");
        } else {
            log.info("No verify button found — OTP auto-submitted");
        }
        waitUtil.sleep(3000);
    }

    public boolean hasError() {
        return isPresent(otpErrorMsg);
    }

    public String getErrorMessage() {
        return isPresent(otpErrorMsg) ? getText(otpErrorMsg) : "";
    }

    public void clickResend() {
        if (isPresent(resendOtpBtn)) {
            click(resendOtpBtn);
            log.info("Clicked resend OTP");
            waitUtil.sleep(2000);
        }
    }
}
