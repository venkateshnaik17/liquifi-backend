package com.liquifi.automation.relay;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;

/**
 * Worker-side OTP relay: polls Redis until the user submits OTP via LiquiFi frontend.
 * OTP is consumed (deleted) immediately after reading — never persisted.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class OtpRedisRelay {

    private final StringRedisTemplate redisTemplate;

    @Value("${liquifi.redis.otp-key-prefix}")
    private String otpKeyPrefix;

    @Value("${liquifi.automation.otp-poll-interval-ms:2000}")
    private long pollIntervalMs;

    @Value("${liquifi.automation.otp-max-wait-seconds:120}")
    private int maxWaitSeconds;

    /**
     * Blocks until OTP is available in Redis or timeout is reached.
     * @return the OTP string
     * @throws RuntimeException if timed out waiting for OTP
     */
    public String waitForOtp(String sessionId) {
        String key = otpKeyPrefix + sessionId;
        long deadline = System.currentTimeMillis() + (maxWaitSeconds * 1000L);

        log.info("Waiting for OTP for session={}. Max wait={}s", sessionId, maxWaitSeconds);

        while (System.currentTimeMillis() < deadline) {
            String otp = redisTemplate.opsForValue().getAndDelete(key);
            if (otp != null && !otp.isBlank()) {
                log.info("OTP received and consumed for session={}", sessionId);
                return otp;
            }
            try {
                Thread.sleep(pollIntervalMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new RuntimeException("OTP wait interrupted for session: " + sessionId);
            }
        }

        throw new RuntimeException("Timed out waiting for OTP for session: " + sessionId);
    }

    public void cleanup(String sessionId) {
        redisTemplate.delete(otpKeyPrefix + sessionId);
    }
}
