package com.liquifi.automation.store;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Persists the extracted CIBIL result directly to Supabase (PostgreSQL) via JdbcTemplate.
 * Uses JSONB for credit_summary and loan_eligibility columns.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class ResultPersistenceService {

    private final JdbcTemplate jdbcTemplate;
    private final ObjectMapper objectMapper;

    @Transactional
    public void save(String sessionId,
                     String mobileNumber,
                     String panCard,
                     String fullName,
                     Integer creditScore,
                     String scoreBand,
                     LocalDate scoreAsOfDate,
                     Map<String, Object> creditSummary,
                     List<Map<String, Object>> loanEligibility,
                     String rawHtmlSnapshot,
                     String screenshotPath) {
        try {
            String summaryJson     = objectMapper.writeValueAsString(creditSummary);
            String eligibilityJson = objectMapper.writeValueAsString(loanEligibility);

            String sql = """
                INSERT INTO cibil_results
                  (session_id, mobile_number, pan_card, full_name,
                   credit_score, score_band, score_as_of_date,
                   credit_summary, loan_eligibility,
                   raw_html_snapshot, screenshot_path, extracted_at)
                VALUES (?,?,?,?,?,?,?,?::jsonb,?::jsonb,?,?,?)
                ON CONFLICT (session_id) DO UPDATE SET
                  credit_score      = EXCLUDED.credit_score,
                  score_band        = EXCLUDED.score_band,
                  credit_summary    = EXCLUDED.credit_summary,
                  loan_eligibility  = EXCLUDED.loan_eligibility,
                  extracted_at      = EXCLUDED.extracted_at
                """;

            jdbcTemplate.update(sql,
                sessionId, mobileNumber, panCard, fullName,
                creditScore, scoreBand, scoreAsOfDate,
                summaryJson, eligibilityJson,
                rawHtmlSnapshot, screenshotPath,
                LocalDateTime.now()
            );

            log.info("CIBIL result persisted to Supabase for session={}", sessionId);

        } catch (Exception e) {
            log.error("Failed to persist CIBIL result for session={}: {}", sessionId, e.getMessage(), e);
            throw new RuntimeException("DB persistence failed for session: " + sessionId, e);
        }
    }

    @Transactional
    public void updateSessionStatus(String sessionId, String status, String errorMessage) {
        String sql = """
            UPDATE cibil_sessions
            SET status = ?::session_status,
                error_message = ?,
                updated_at = NOW()
            WHERE session_id = ?
            """;
        jdbcTemplate.update(sql, status, errorMessage, sessionId);
        log.info("Session={} status updated to={}", sessionId, status);
    }
}
