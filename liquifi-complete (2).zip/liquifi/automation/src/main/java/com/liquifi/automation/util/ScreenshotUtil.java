package com.liquifi.automation.util;

import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class ScreenshotUtil {

    @Value("${liquifi.automation.screenshot-dir:/var/liquifi/screenshots}")
    private String screenshotDir;

    /**
     * Captures a screenshot and saves it to the configured directory.
     * @return absolute path of the saved screenshot file
     */
    public String capture(WebDriver driver, String sessionId, String step) {
        try {
            Path dir = Paths.get(screenshotDir, sessionId);
            Files.createDirectories(dir);

            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            String filename = step + "_" + timestamp + ".png";
            Path filePath = dir.resolve(filename);

            File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            Files.copy(screenshot.toPath(), filePath);

            log.info("Screenshot saved: {}", filePath);
            return filePath.toAbsolutePath().toString();
        } catch (IOException e) {
            log.error("Failed to save screenshot for session={} step={}", sessionId, step, e);
            return null;
        }
    }
}
