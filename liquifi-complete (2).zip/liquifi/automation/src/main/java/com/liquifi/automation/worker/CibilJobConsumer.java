package com.liquifi.automation.worker;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.liquifi.automation.workflow.CibilWorkflow;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Long-running Redis queue consumer.
 * Uses BLPOP (blocking left-pop) to wait for new jobs efficiently.
 * Spawns one thread per worker slot (controlled by worker-concurrency).
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class CibilJobConsumer {

    private final StringRedisTemplate redisTemplate;
    private final ObjectMapper        objectMapper;
    private final CibilWorkflow       cibilWorkflow;

    @Value("${liquifi.redis.cibil-job-queue}")
    private String jobQueue;

    @Value("${liquifi.automation.worker-concurrency:3}")
    private int workerConcurrency;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private ExecutorService executorService;

    @PostConstruct
    public void start() {
        running.set(true);
        executorService = Executors.newFixedThreadPool(workerConcurrency);

        for (int i = 0; i < workerConcurrency; i++) {
            final int workerId = i + 1;
            executorService.submit(() -> pollLoop(workerId));
        }

        log.info("CibilJobConsumer started with {} worker threads", workerConcurrency);
    }

    private void pollLoop(int workerId) {
        log.info("Worker-{} listening on queue: {}", workerId, jobQueue);

        while (running.get()) {
            try {
                // Blocking pop — waits up to 5s for a job, then loops
                var result = redisTemplate.opsForList()
                    .leftPop(jobQueue, Duration.ofSeconds(5));

                if (result == null) continue;

                CibilJobPayload payload = objectMapper.readValue(result, CibilJobPayload.class);
                log.info("Worker-{} picked up job for session={}", workerId, payload.getSessionId());

                cibilWorkflow.execute(payload);

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.warn("Worker-{} interrupted", workerId);
                break;
            } catch (Exception e) {
                log.error("Worker-{} error processing job: {}", workerId, e.getMessage(), e);
                // Brief back-off before next poll to prevent tight error loops
                try { Thread.sleep(2000); } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        log.info("Worker-{} stopped", workerId);
    }

    @PreDestroy
    public void stop() {
        running.set(false);
        if (executorService != null) {
            executorService.shutdown();
        }
        log.info("CibilJobConsumer shutdown initiated");
    }
}
