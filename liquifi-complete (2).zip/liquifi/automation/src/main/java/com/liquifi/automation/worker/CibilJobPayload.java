package com.liquifi.automation.worker;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CibilJobPayload {
    private String    sessionId;
    private String    fullName;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate dob;

    private String    mobileNumber;
    private String    email;
    private String    panCard;
    private long      enqueuedAt;
}
