package com.liquifi.automation.workflow;

import com.liquifi.automation.browser.BrowserFactory;
import com.liquifi.automation.browser.BrowserSession;
import com.liquifi.automation.store.ResultPersistenceService;
import com.liquifi.automation.util.WaitUtil;
import com.liquifi.automation.worker.CibilJobPayload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * Orchestrates the full CIBIL automation workflow:
 * Browser Launch → Form Fill → OTP Wait → Result Extract
 * Each session gets its own isolated browser instance.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class CibilWorkflow {

    private final BrowserFactory           browserFactory;
    private final FormFillStep             formFillStep;
    private final OtpWaitStep              otpWaitStep;
    private final ResultExtractStep        resultExtractStep;
    private final ResultPersistenceService persistenceService;
    private final WaitUtil                 waitUtil;

    public void execute(CibilJobPayload payload) {
        String sessionId = payload.getSessionId();
        log.info("=== CibilWorkflow START | session={} ===", sessionId);

        try (BrowserSession browserSession = browserFactory.createSession(sessionId)) {

            // Step 1: Navigate to UrbanMoney + fill form
            formFillStep.execute(browserSession.getDriver(), waitUtil, payload);

            // Step 2: Wait for OTP page, relay OTP from Redis
            otpWaitStep.execute(browserSession.getDriver(), waitUtil, sessionId);

            // Step 3: Extract result data and persist to Supabase
            resultExtractStep.execute(browserSession.getDriver(), waitUtil, payload);

            log.info("=== CibilWorkflow COMPLETED | session={} ===", sessionId);

        } catch (Exception e) {
            log.error("=== CibilWorkflow FAILED | session={} | reason={} ===", sessionId, e.getMessage(), e);
            try {
                persistenceService.updateSessionStatus(sessionId, "FAILED", e.getMessage());
            } catch (Exception dbEx) {
                log.error("Could not update session to FAILED in DB: {}", dbEx.getMessage());
            }
        }
    }
}
