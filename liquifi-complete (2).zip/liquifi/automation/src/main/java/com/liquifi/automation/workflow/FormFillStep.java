package com.liquifi.automation.workflow;

import com.liquifi.automation.pages.UrbanMoneyCibilFormPage;
import com.liquifi.automation.pages.UrbanMoneyLandingPage;
import com.liquifi.automation.store.ResultPersistenceService;
import com.liquifi.automation.util.ScreenshotUtil;
import com.liquifi.automation.util.WaitUtil;
import com.liquifi.automation.worker.CibilJobPayload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class FormFillStep {

    private final ScreenshotUtil screenshotUtil;
    private final ResultPersistenceService persistenceService;

    public void execute(WebDriver driver, WaitUtil waitUtil, CibilJobPayload payload) {
        String sessionId = payload.getSessionId();

        try {
            persistenceService.updateSessionStatus(sessionId, "BROWSER_LAUNCHED", null);

            // 1. Open landing page
            UrbanMoneyLandingPage landingPage = new UrbanMoneyLandingPage(driver, waitUtil);
            landingPage.open();
            screenshotUtil.capture(driver, sessionId, "01_landing");

            // 2. Navigate to CIBIL form
            landingPage.navigateToForm();
            screenshotUtil.capture(driver, sessionId, "02_form_opened");

            // 3. Fill and submit form
            UrbanMoneyCibilFormPage formPage = new UrbanMoneyCibilFormPage(driver, waitUtil);
            formPage.fillAndSubmit(
                payload.getFullName(),
                payload.getDob(),
                payload.getMobileNumber(),
                payload.getEmail(),
                payload.getPanCard()
            );

            screenshotUtil.capture(driver, sessionId, "03_form_submitted");
            persistenceService.updateSessionStatus(sessionId, "FORM_FILLED", null);
            log.info("FormFillStep completed for session={}", sessionId);

        } catch (Exception e) {
            screenshotUtil.capture(driver, sessionId, "error_form_fill");
            log.error("FormFillStep failed for session={}: {}", sessionId, e.getMessage(), e);
            throw new RuntimeException("Form fill failed: " + e.getMessage(), e);
        }
    }
}
