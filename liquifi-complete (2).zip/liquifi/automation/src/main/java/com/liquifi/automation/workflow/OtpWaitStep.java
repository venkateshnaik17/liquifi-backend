package com.liquifi.automation.workflow;

import com.liquifi.automation.pages.UrbanMoneyOtpPage;
import com.liquifi.automation.relay.OtpRedisRelay;
import com.liquifi.automation.store.ResultPersistenceService;
import com.liquifi.automation.util.ScreenshotUtil;
import com.liquifi.automation.util.WaitUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class OtpWaitStep {

    private final OtpRedisRelay otpRedisRelay;
    private final ScreenshotUtil screenshotUtil;
    private final ResultPersistenceService persistenceService;

    public void execute(WebDriver driver, WaitUtil waitUtil, String sessionId) {
        try {
            UrbanMoneyOtpPage otpPage = new UrbanMoneyOtpPage(driver, waitUtil);

            // Confirm OTP page is shown
            if (!otpPage.isOtpPageVisible()) {
                log.warn("OTP page not detected for session={}. Checking current URL: {}", sessionId, driver.getCurrentUrl());
                screenshotUtil.capture(driver, sessionId, "warn_otp_page_not_found");
            }

            screenshotUtil.capture(driver, sessionId, "04_otp_page");

            // Signal backend: session is waiting for OTP input from user
            persistenceService.updateSessionStatus(sessionId, "OTP_AWAITED", null);
            log.info("OTP page active. Waiting for user OTP input via Redis. session={}", sessionId);

            // Block until user submits OTP on LiquiFi frontend → backend → Redis
            String otp = otpRedisRelay.waitForOtp(sessionId);
            log.info("OTP received from Redis for session={}", sessionId);

            // Enter OTP on UrbanMoney page
            otpPage.enterOtp(otp);
            screenshotUtil.capture(driver, sessionId, "05_otp_entered");

            otpPage.clickVerify();
            screenshotUtil.capture(driver, sessionId, "06_otp_submitted");

            if (otpPage.hasError()) {
                String errMsg = otpPage.getErrorMessage();
                log.error("OTP error on page for session={}: {}", sessionId, errMsg);
                throw new RuntimeException("OTP verification failed: " + errMsg);
            }

            persistenceService.updateSessionStatus(sessionId, "OTP_SUBMITTED", null);
            log.info("OtpWaitStep completed for session={}", sessionId);

        } catch (Exception e) {
            screenshotUtil.capture(driver, sessionId, "error_otp");
            log.error("OtpWaitStep failed for session={}: {}", sessionId, e.getMessage(), e);
            throw new RuntimeException("OTP step failed: " + e.getMessage(), e);
        }
    }
}
