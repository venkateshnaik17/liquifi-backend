package com.liquifi.automation.workflow;

import com.liquifi.automation.extractor.CibilScoreExtractor;
import com.liquifi.automation.extractor.CreditSummaryExtractor;
import com.liquifi.automation.extractor.LoanEligibilityExtractor;
import com.liquifi.automation.pages.UrbanMoneyCibilResultPage;
import com.liquifi.automation.store.ResultPersistenceService;
import com.liquifi.automation.util.ScreenshotUtil;
import com.liquifi.automation.util.WaitUtil;
import com.liquifi.automation.worker.CibilJobPayload;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.openqa.selenium.WebDriver;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Component
@RequiredArgsConstructor
@Slf4j
public class ResultExtractStep {

    private final CibilScoreExtractor       scoreExtractor;
    private final CreditSummaryExtractor    summaryExtractor;
    private final LoanEligibilityExtractor  loanExtractor;
    private final ResultPersistenceService  persistenceService;
    private final ScreenshotUtil            screenshotUtil;

    public void execute(WebDriver driver, WaitUtil waitUtil, CibilJobPayload payload) {
        String sessionId = payload.getSessionId();

        try {
            persistenceService.updateSessionStatus(sessionId, "EXTRACTING", null);

            UrbanMoneyCibilResultPage resultPage = new UrbanMoneyCibilResultPage(driver, waitUtil);

            // Confirm result page loaded
            if (!resultPage.isResultPageLoaded()) {
                log.warn("Result page may not be fully loaded for session={}", sessionId);
                waitUtil.sleep(5000); // extra wait
            }

            screenshotUtil.capture(driver, sessionId, "07_result_page");

            // Extract all data
            Map<String, Object> scoreData       = scoreExtractor.extract(resultPage);
            Map<String, Object> summaryData     = summaryExtractor.extract(resultPage);
            List<Map<String, Object>> loanData  = loanExtractor.extract(resultPage);
            String rawHtml                       = resultPage.getFullPageSource();
            String screenshotPath               = screenshotUtil.capture(driver, sessionId, "08_result_final");

            Integer creditScore   = (Integer) scoreData.get("score");
            String  scoreBand     = (String)  scoreData.get("scoreBand");
            LocalDate scoreDate   = (LocalDate) scoreData.getOrDefault("scoreAsOfDate", LocalDate.now());

            log.info("Extraction complete for session={} | score={} | band={}", sessionId, creditScore, scoreBand);

            // Persist to Supabase
            persistenceService.save(
                sessionId,
                payload.getMobileNumber(),
                payload.getPanCard(),
                payload.getFullName(),
                creditScore,
                scoreBand,
                scoreDate,
                summaryData,
                loanData,
                rawHtml,
                screenshotPath
            );

            persistenceService.updateSessionStatus(sessionId, "COMPLETED", null);
            log.info("ResultExtractStep completed for session={}", sessionId);

        } catch (Exception e) {
            screenshotUtil.capture(driver, sessionId, "error_extraction");
            log.error("ResultExtractStep failed for session={}: {}", sessionId, e.getMessage(), e);
            throw new RuntimeException("Result extraction failed: " + e.getMessage(), e);
        }
    }
}
