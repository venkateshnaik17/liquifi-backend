package com.liquifi.automation.workflow;

import com.liquifi.automation.browser.BrowserFactory;
import com.liquifi.automation.browser.BrowserSession;
import com.liquifi.automation.store.ResultPersistenceService;
import com.liquifi.automation.util.WaitUtil;
import com.liquifi.automation.worker.CibilJobPayload;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.openqa.selenium.WebDriver;

import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CibilWorkflowTest {

    @Mock BrowserFactory           browserFactory;
    @Mock BrowserSession           browserSession;
    @Mock WebDriver                webDriver;
    @Mock FormFillStep             formFillStep;
    @Mock OtpWaitStep              otpWaitStep;
    @Mock ResultExtractStep        resultExtractStep;
    @Mock ResultPersistenceService persistenceService;
    @Mock WaitUtil                 waitUtil;

    @InjectMocks CibilWorkflow cibilWorkflow;

    private CibilJobPayload payload;

    @BeforeEach
    void setUp() {
        payload = CibilJobPayload.builder()
            .sessionId("test-session-001")
            .fullName("Ravi Kumar")
            .dob(LocalDate.of(1990, 5, 15))
            .mobileNumber("9876543210")
            .email("ravi@example.com")
            .panCard("ABCDE1234F")
            .enqueuedAt(System.currentTimeMillis())
            .build();

        when(browserFactory.createSession(any())).thenReturn(browserSession);
        when(browserSession.getDriver()).thenReturn(webDriver);
    }

    @Test
    void execute_successPath_callsAllSteps() {
        cibilWorkflow.execute(payload);

        verify(formFillStep,      times(1)).execute(any(), any(), eq(payload));
        verify(otpWaitStep,       times(1)).execute(any(), any(), eq("test-session-001"));
        verify(resultExtractStep, times(1)).execute(any(), any(), eq(payload));
        verify(browserSession,    times(1)).close();
    }

    @Test
    void execute_formFillFails_marksSessionFailed() {
        doThrow(new RuntimeException("Form fill error"))
            .when(formFillStep).execute(any(), any(), any());

        cibilWorkflow.execute(payload);

        verify(persistenceService, times(1))
            .updateSessionStatus(eq("test-session-001"), eq("FAILED"), contains("Form fill error"));
        verify(browserSession, times(1)).close();
    }

    @Test
    void execute_otpStepFails_marksSessionFailedAndClosedBrowser() {
        doThrow(new RuntimeException("OTP timeout"))
            .when(otpWaitStep).execute(any(), any(), any());

        cibilWorkflow.execute(payload);

        verify(persistenceService, times(1))
            .updateSessionStatus(eq("test-session-001"), eq("FAILED"), contains("OTP timeout"));
        verify(browserSession, times(1)).close();
    }
}
