import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@/store/store';
import Header      from '@/components/layout/Header';
import Footer      from '@/components/layout/Footer';
import CibilPage   from '@/pages/CibilPage';
import ResultPage  from '@/pages/ResultPage';
import ErrorBoundary from '@/components/common/ErrorBoundary';
import { Toaster } from 'react-hot-toast';

const App: React.FC = () => {
  const currentStep = useSelector((s: RootState) => s.cibil.currentStep);

  return (
    <ErrorBoundary>
      <div className="min-h-screen flex flex-col bg-gradient-to-br from-slate-50 to-indigo-50">
        <Header />

        <main className="flex-1 w-full max-w-2xl mx-auto px-4 sm:px-6 py-10">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
            {currentStep === 'RESULT' ? <ResultPage /> : <CibilPage />}
          </div>
        </main>

        <Footer />
        <Toaster position="top-right" toastOptions={{ duration: 4000 }} />
      </div>
    </ErrorBoundary>
  );
};

export default App;
