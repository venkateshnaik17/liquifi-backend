import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { User, Calendar, Phone, Mail, CreditCard } from 'lucide-react';
import { cibilFormSchema, CibilFormSchema } from '@/utils/validators';
import Input from '@/components/common/Input';
import Button from '@/components/common/Button';
import ConsentModal from './ConsentModal';
import { CibilFormData } from '@/types/cibil.types';

interface CibilFormProps {
  onSubmit: (data: CibilFormData) => Promise<void>;
  isLoading: boolean;
}

const CibilForm: React.FC<CibilFormProps> = ({ onSubmit, isLoading }) => {
  const [showConsent, setShowConsent] = useState(false);
  const [pendingData, setPendingData] = useState<CibilFormSchema | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<CibilFormSchema>({
    resolver: zodResolver(cibilFormSchema),
    defaultValues: { consentGiven: false },
  });

  const onFormSubmit = (data: CibilFormSchema) => {
    setPendingData(data);
    setShowConsent(true);
  };

  const handleConsentAccept = async () => {
    if (!pendingData) return;
    setShowConsent(false);
    await onSubmit({ ...pendingData, consentGiven: true });
  };

  return (
    <>
      <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-5" noValidate>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div className="sm:col-span-2">
            <Input
              label="Full Name"
              placeholder="As per PAN Card"
              required
              error={errors.fullName?.message}
              {...register('fullName')}
            />
          </div>

          <Input
            label="Date of Birth"
            type="date"
            required
            error={errors.dob?.message}
            max={new Date().toISOString().split('T')[0]}
            {...register('dob')}
          />

          <Input
            label="Mobile Number"
            type="tel"
            placeholder="10-digit mobile number"
            maxLength={10}
            required
            error={errors.mobileNumber?.message}
            helpText="OTP will be sent to this number"
            {...register('mobileNumber')}
          />

          <Input
            label="Email Address"
            type="email"
            placeholder="your@email.com"
            required
            error={errors.email?.message}
            {...register('email')}
          />

          <Input
            label="PAN Card"
            placeholder="ABCDE1234F"
            maxLength={10}
            required
            error={errors.panCard?.message}
            className="uppercase"
            {...register('panCard')}
          />
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-xs text-blue-700 leading-relaxed">
            🔒 By clicking "Check My CIBIL Score", you consent to share your credit
            information with UrbanMoney as per TUCIBIL's terms. This will NOT affect your credit score.
          </p>
        </div>

        <Button
          type="submit"
          fullWidth
          size="lg"
          loading={isLoading}
          className="mt-2"
        >
          Check My CIBIL Score
        </Button>
      </form>

      {showConsent && (
        <ConsentModal
          onAccept={handleConsentAccept}
          onCancel={() => setShowConsent(false)}
          loading={isLoading}
        />
      )}
    </>
  );
};

export default CibilForm;
