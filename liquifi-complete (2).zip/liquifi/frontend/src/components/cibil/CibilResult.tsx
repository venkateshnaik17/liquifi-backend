import React from 'react';
import { RefreshCw, Download } from 'lucide-react';
import { CibilResult as CibilResultType } from '@/types/cibil.types';
import CreditScoreCard    from './CreditScoreCard';
import CreditSummaryCard  from './CreditSummaryCard';
import LoanEligibilityCard from './LoanEligibilityCard';
import Button from '@/components/common/Button';
import { formatDate } from '@/utils/formatters';

interface CibilResultProps {
  result:  CibilResultType;
  onReset: () => void;
}

const CibilResult: React.FC<CibilResultProps> = ({ result, onReset }) => (
  <div className="space-y-6">
    <div className="flex items-center justify-between">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Your Credit Report</h2>
        <p className="text-sm text-gray-500 mt-0.5">
          Fetched on {formatDate(result.extractedAt)}
        </p>
      </div>
      <Button variant="ghost" size="sm" onClick={onReset}>
        <RefreshCw className="w-4 h-4" />
        Check Again
      </Button>
    </div>

    {/* Score + Summary + Loans */}
    <CreditScoreCard result={result} />

    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      <CreditSummaryCard  summary={result.creditSummary} />
      <LoanEligibilityCard loans={result.loanEligibility ?? []} />
    </div>

    {/* Disclaimer */}
    <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 text-xs text-gray-500 space-y-1">
      <p className="font-medium text-gray-700">Disclaimer</p>
      <p>
        Credit score data is provided by TransUnion CIBIL (TUCIBIL) via UrbanMoney.
        LiquiFi is not responsible for inaccuracies in the score. Please contact TUCIBIL directly
        for disputes. This check does not constitute a credit enquiry.
      </p>
    </div>
  </div>
);

export default CibilResult;
