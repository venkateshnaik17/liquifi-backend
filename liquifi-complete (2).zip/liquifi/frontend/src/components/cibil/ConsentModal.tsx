import React from 'react';
import { ShieldCheck, X } from 'lucide-react';
import Button from '@/components/common/Button';

const CONSENT_TEXT =
  'I agree to the Terms and Conditions of TUCIBIL and hereby provide explicit consent ' +
  'to share my Credit Information with Urban Money Private Limited.';

interface ConsentModalProps {
  onAccept: () => void;
  onCancel: () => void;
  loading:  boolean;
}

const ConsentModal: React.FC<ConsentModalProps> = ({ onAccept, onCancel, loading }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">
    <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full p-6 relative">
      <button
        onClick={onCancel}
        className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
      >
        <X className="w-5 h-5" />
      </button>

      <div className="flex items-center gap-3 mb-5">
        <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
          <ShieldCheck className="w-5 h-5 text-indigo-600" />
        </div>
        <div>
          <h3 className="font-semibold text-gray-900 text-lg">Consent Required</h3>
          <p className="text-xs text-gray-500">TUCIBIL & UrbanMoney</p>
        </div>
      </div>

      <div className="bg-gray-50 rounded-lg border border-gray-200 p-4 mb-6">
        <p className="text-sm text-gray-700 leading-relaxed">{CONSENT_TEXT}</p>
      </div>

      <div className="text-xs text-gray-500 mb-5 space-y-1">
        <p>• Your data is encrypted using 256-bit SSL</p>
        <p>• We never store or sell your information to third parties</p>
        <p>• This check will not affect your credit score</p>
      </div>

      <div className="flex gap-3">
        <Button variant="secondary" fullWidth onClick={onCancel} disabled={loading}>
          Cancel
        </Button>
        <Button variant="primary" fullWidth onClick={onAccept} loading={loading}>
          I Agree & Proceed
        </Button>
      </div>
    </div>
  </div>
);

export default ConsentModal;
