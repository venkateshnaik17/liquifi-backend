import React from 'react';
import { clsx } from 'clsx';
import { getScoreBandColor, getScoreBandBg, formatDate } from '@/utils/formatters';
import { CibilResult } from '@/types/cibil.types';

interface CreditScoreCardProps {
  result: CibilResult;
}

const CreditScoreCard: React.FC<CreditScoreCardProps> = ({ result }) => {
  const { creditScore, scoreBand, scoreAsOfDate, fullName } = result;

  const scoreColor = getScoreBandColor(scoreBand);
  const scoreBg    = getScoreBandBg(scoreBand);

  // Score arc calculation (300-900 range → 0-180 degrees)
  const pct = creditScore
    ? Math.round(((creditScore - 300) / 600) * 100)
    : 0;

  return (
    <div className={clsx('rounded-2xl border-2 p-6 text-center shadow-sm', scoreBg)}>
      <p className="text-sm text-gray-600 mb-1">Credit Score for</p>
      <p className="font-semibold text-gray-900 mb-4">{fullName}</p>

      {/* Score Circle */}
      <div className="relative w-40 h-40 mx-auto mb-4">
        <svg viewBox="0 0 160 160" className="w-full h-full -rotate-90">
          <circle cx="80" cy="80" r="68" fill="none" stroke="#e5e7eb" strokeWidth="12" />
          <circle
            cx="80" cy="80" r="68"
            fill="none"
            stroke={scoreBand === 'EXCELLENT' ? '#16a34a' :
                    scoreBand === 'GOOD'      ? '#2563eb' :
                    scoreBand === 'FAIR'      ? '#ca8a04' : '#dc2626'}
            strokeWidth="12"
            strokeDasharray={`${(pct / 100) * 427} 427`}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={clsx('text-4xl font-extrabold', scoreColor)}>
            {creditScore ?? '—'}
          </span>
          <span className="text-xs text-gray-500 mt-1">out of 900</span>
        </div>
      </div>

      {/* Score Band */}
      {scoreBand && (
        <span className={clsx(
          'inline-block px-4 py-1 rounded-full text-sm font-bold uppercase tracking-wide',
          scoreColor
        )}>
          {scoreBand}
        </span>
      )}

      {scoreAsOfDate && (
        <p className="text-xs text-gray-500 mt-3">
          Score as of {formatDate(scoreAsOfDate)}
        </p>
      )}
    </div>
  );
};

export default CreditScoreCard;
