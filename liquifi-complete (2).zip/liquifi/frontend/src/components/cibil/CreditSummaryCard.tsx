import React from 'react';
import { BarChart3 } from 'lucide-react';
import { CreditSummary } from '@/types/cibil.types';
import { formatCurrency } from '@/utils/formatters';

interface CreditSummaryCardProps {
  summary: CreditSummary | null;
}

const StatRow: React.FC<{ label: string; value: React.ReactNode; highlight?: boolean }> = ({
  label, value, highlight
}) => (
  <div className="flex justify-between items-center py-2.5 border-b border-gray-100 last:border-0">
    <span className="text-sm text-gray-600">{label}</span>
    <span className={`text-sm font-semibold ${highlight ? 'text-red-600' : 'text-gray-900'}`}>
      {value ?? 'N/A'}
    </span>
  </div>
);

const CreditSummaryCard: React.FC<CreditSummaryCardProps> = ({ summary }) => (
  <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
    <div className="flex items-center gap-2 mb-4">
      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
        <BarChart3 className="w-4 h-4 text-blue-600" />
      </div>
      <h3 className="font-semibold text-gray-900">Credit Summary</h3>
    </div>

    {summary ? (
      <div>
        <StatRow label="Total Accounts"    value={summary.totalAccounts} />
        <StatRow label="Active Accounts"   value={summary.activeAccounts} />
        <StatRow label="Closed Accounts"   value={summary.closedAccounts} />
        <StatRow
          label="Overdue Accounts"
          value={summary.overdueAccounts}
          highlight={(summary.overdueAccounts ?? 0) > 0}
        />
        <StatRow label="Total Credit Limit" value={formatCurrency(summary.totalCreditLimit)} />
        <StatRow label="Current Balance"    value={formatCurrency(summary.totalBalance)} />
      </div>
    ) : (
      <p className="text-sm text-gray-500 text-center py-4">No summary data available</p>
    )}
  </div>
);

export default CreditSummaryCard;
