import React from 'react';
import { BadgeCheck, XCircle, Banknote } from 'lucide-react';
import { LoanEligibility } from '@/types/cibil.types';
import { clsx } from 'clsx';

interface LoanEligibilityCardProps {
  loans: LoanEligibility[];
}

const EligibilityBadge: React.FC<{ status: string }> = ({ status }) => {
  if (status === 'ELIGIBLE' || status === 'PRE_APPROVED') {
    return (
      <span className="inline-flex items-center gap-1 text-xs font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
        <BadgeCheck className="w-3 h-3" />
        {status === 'PRE_APPROVED' ? 'Pre-Approved' : 'Eligible'}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-xs font-medium text-red-700 bg-red-100 px-2 py-0.5 rounded-full">
      <XCircle className="w-3 h-3" />
      Not Eligible
    </span>
  );
};

const LoanEligibilityCard: React.FC<LoanEligibilityCardProps> = ({ loans }) => (
  <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6">
    <div className="flex items-center gap-2 mb-4">
      <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
        <Banknote className="w-4 h-4 text-green-600" />
      </div>
      <h3 className="font-semibold text-gray-900">Loan Eligibility</h3>
    </div>

    {loans && loans.length > 0 ? (
      <div className="space-y-3">
        {loans.map((loan, idx) => (
          <div
            key={idx}
            className={clsx(
              'flex items-start justify-between p-3 rounded-xl border',
              loan.eligibilityStatus === 'ELIGIBLE' || loan.eligibilityStatus === 'PRE_APPROVED'
                ? 'bg-green-50 border-green-200'
                : 'bg-gray-50 border-gray-200'
            )}
          >
            <div className="space-y-1">
              <p className="text-sm font-semibold text-gray-900">{loan.loanType}</p>
              {loan.maxAmount    && <p className="text-xs text-gray-600">Up to {loan.maxAmount}</p>}
              {loan.interestRate && <p className="text-xs text-gray-500">Rate: {loan.interestRate}</p>}
              {loan.tenure       && <p className="text-xs text-gray-500">Tenure: {loan.tenure}</p>}
            </div>
            <EligibilityBadge status={loan.eligibilityStatus} />
          </div>
        ))}
      </div>
    ) : (
      <p className="text-sm text-gray-500 text-center py-4">
        No loan eligibility data available
      </p>
    )}
  </div>
);

export default LoanEligibilityCard;
