import React, { useRef, useState, useEffect } from 'react';
import { MessageSquare, RefreshCw } from 'lucide-react';
import Button from '@/components/common/Button';
import { useOtpPolling } from '@/hooks/useOtpPolling';

interface OtpVerificationProps {
  sessionId: string;
  mobile:    string;
  onSuccess: () => void;
}

const OtpVerification: React.FC<OtpVerificationProps> = ({
  sessionId, mobile, onSuccess
}) => {
  const [otpDigits, setOtpDigits] = useState<string[]>(Array(6).fill(''));
  const [countdown, setCountdown] = useState(30);
  const [loading, setLoading]     = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const { submitOtp, otpError } = useOtpPolling(sessionId);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((c) => (c > 0 ? c - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newDigits = [...otpDigits];
    newDigits[index] = value.slice(-1);
    setOtpDigits(newDigits);
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otpDigits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    const digits = pasted.split('');
    const newDigits = [...otpDigits];
    digits.forEach((d, i) => { newDigits[i] = d; });
    setOtpDigits(newDigits);
    inputRefs.current[Math.min(digits.length, 5)]?.focus();
  };

  const handleSubmit = async () => {
    const otp = otpDigits.join('');
    if (otp.length < 4) return;
    setLoading(true);
    const success = await submitOtp(otp);
    setLoading(false);
    if (success) onSuccess();
  };

  const maskedMobile = mobile
    ? mobile.slice(0, 2) + 'XXXXXX' + mobile.slice(-2)
    : 'your number';

  return (
    <div className="max-w-md mx-auto text-center space-y-6">
      <div className="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto">
        <MessageSquare className="w-8 h-8 text-indigo-600" />
      </div>

      <div>
        <h2 className="text-2xl font-bold text-gray-900">Enter OTP</h2>
        <p className="text-gray-600 mt-1 text-sm">
          A 6-digit OTP has been sent to <strong>{maskedMobile}</strong>
        </p>
      </div>

      {/* OTP Input Boxes */}
      <div className="flex justify-center gap-3" onPaste={handlePaste}>
        {otpDigits.map((digit, index) => (
          <input
            key={index}
            ref={(el) => { inputRefs.current[index] = el; }}
            type="tel"
            maxLength={1}
            value={digit}
            onChange={(e) => handleChange(index, e.target.value)}
            onKeyDown={(e) => handleKeyDown(index, e)}
            className="w-12 h-14 text-center text-xl font-bold border-2 rounded-xl
                       focus:outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200
                       border-gray-300 bg-white transition-colors"
          />
        ))}
      </div>

      {otpError && (
        <p className="text-sm text-red-600">{otpError}</p>
      )}

      <Button
        fullWidth
        size="lg"
        loading={loading}
        disabled={otpDigits.join('').length < 4}
        onClick={handleSubmit}
      >
        Verify OTP
      </Button>

      <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
        {countdown > 0 ? (
          <span>Resend OTP in <strong className="text-indigo-600">{countdown}s</strong></span>
        ) : (
          <button
            className="flex items-center gap-1 text-indigo-600 hover:underline font-medium"
            onClick={() => setCountdown(30)}
          >
            <RefreshCw className="w-4 h-4" /> Resend OTP
          </button>
        )}
      </div>
    </div>
  );
};

export default OtpVerification;
