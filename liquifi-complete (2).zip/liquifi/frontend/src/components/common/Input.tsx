import React from 'react';
import { clsx } from 'clsx';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label:        string;
  error?:       string;
  helpText?:    string;
  required?:    boolean;
}

const Input: React.FC<InputProps> = ({
  label, error, helpText, required,
  className, id, ...rest
}) => {
  const inputId = id ?? label.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className="flex flex-col gap-1">
      <label htmlFor={inputId} className="text-sm font-medium text-gray-700">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <input
        id={inputId}
        className={clsx(
          'block w-full rounded-lg border px-3.5 py-2.5 text-sm text-gray-900',
          'placeholder:text-gray-400 shadow-sm transition-colors',
          'focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500',
          error
            ? 'border-red-400 bg-red-50 focus:ring-red-400'
            : 'border-gray-300 bg-white',
          className
        )}
        {...rest}
      />
      {error && (
        <p className="text-xs text-red-600 flex items-center gap-1">{error}</p>
      )}
      {helpText && !error && (
        <p className="text-xs text-gray-500">{helpText}</p>
      )}
    </div>
  );
};

export default Input;
