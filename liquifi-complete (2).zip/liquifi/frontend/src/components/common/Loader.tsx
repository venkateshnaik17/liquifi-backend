import React from 'react';
import { Loader2 } from 'lucide-react';
import { clsx } from 'clsx';

interface LoaderProps {
  message?: string;
  size?:    'sm' | 'md' | 'lg';
  fullPage?: boolean;
}

const sizeMap = { sm: 'w-4 h-4', md: 'w-8 h-8', lg: 'w-12 h-12' };

const Loader: React.FC<LoaderProps> = ({
  message, size = 'md', fullPage = false
}) => (
  <div className={clsx(
    'flex flex-col items-center justify-center gap-3',
    fullPage && 'min-h-[400px]'
  )}>
    <Loader2 className={clsx('animate-spin text-indigo-600', sizeMap[size])} />
    {message && (
      <p className="text-sm text-gray-600 animate-pulse text-center max-w-xs">{message}</p>
    )}
  </div>
);

export default Loader;
