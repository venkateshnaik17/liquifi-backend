import React from 'react';

const Footer: React.FC = () => (
  <footer className="bg-gray-50 border-t border-gray-200 py-6 mt-auto">
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-gray-500 space-y-1">
      <p>© {new Date().getFullYear()} LiquiFi. All rights reserved.</p>
      <p>
        Credit score data is sourced from TUCIBIL via UrbanMoney.
        Your data is encrypted and never shared with third parties.
      </p>
    </div>
  </footer>
);

export default Footer;
