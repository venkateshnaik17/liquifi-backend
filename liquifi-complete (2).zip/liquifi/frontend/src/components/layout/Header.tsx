import React from 'react';
import { ShieldCheck } from 'lucide-react';

const Header: React.FC = () => (
  <header className="bg-white border-b border-gray-200 shadow-sm sticky top-0 z-50">
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
          <span className="text-white font-bold text-sm">L</span>
        </div>
        <span className="text-xl font-bold text-gray-900">LiquiFi</span>
      </div>
      <div className="flex items-center gap-2 text-xs text-gray-500">
        <ShieldCheck className="w-4 h-4 text-green-500" />
        <span>256-bit SSL Encrypted</span>
      </div>
    </div>
  </header>
);

export default Header;
