import { useCallback } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from '@/store/store';
import {
  setLoading, setSessionId, setCurrentStep,
  setError, setResult, resetFlow,
} from '@/store/cibilSlice';
import { cibilService } from '@/services/cibilService';
import { CibilFormData } from '@/types/cibil.types';
import toast from 'react-hot-toast';

export const useCibilFlow = () => {
  const dispatch = useDispatch<AppDispatch>();
  const state    = useSelector((s: RootState) => s.cibil);

  const submitForm = useCallback(async (formData: CibilFormData) => {
    dispatch(setLoading(true));
    try {
      const response = await cibilService.initiate(formData);
      dispatch(setSessionId(response.sessionId));
      dispatch(setCurrentStep('PROCESSING'));
      toast.success('Form submitted! OTP will be sent to your mobile.');
    } catch (err: any) {
      const msg = err?.message ?? 'Failed to submit form. Please try again.';
      dispatch(setError(msg));
      toast.error(msg);
    } finally {
      dispatch(setLoading(false));
    }
  }, [dispatch]);

  const submitOtp = useCallback(async (otp: string) => {
    if (!state.sessionId) return;
    dispatch(setLoading(true));
    try {
      await cibilService.submitOtp(state.sessionId, otp);
      dispatch(setCurrentStep('EXTRACTING'));
      toast.success('OTP verified! Fetching your credit score...');
    } catch (err: any) {
      const msg = err?.message ?? 'Invalid OTP. Please try again.';
      toast.error(msg);
    } finally {
      dispatch(setLoading(false));
    }
  }, [dispatch, state.sessionId]);

  const fetchResult = useCallback(async () => {
    if (!state.sessionId) return;
    try {
      const result = await cibilService.getResult(state.sessionId);
      dispatch(setResult(result));
    } catch (err: any) {
      dispatch(setError(err?.message ?? 'Failed to load result.'));
    }
  }, [dispatch, state.sessionId]);

  const reset = useCallback(() => {
    dispatch(resetFlow());
  }, [dispatch]);

  return { state, submitForm, submitOtp, fetchResult, reset };
};
