import { useState, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/store/store';
import { setLoading, setCurrentStep } from '@/store/cibilSlice';
import { cibilService } from '@/services/cibilService';
import toast from 'react-hot-toast';

export const useOtpPolling = (sessionId: string | null) => {
  const dispatch      = useDispatch<AppDispatch>();
  const [error, setError] = useState<string | null>(null);

  const submitOtp = useCallback(async (otp: string): Promise<boolean> => {
    if (!sessionId) return false;

    setError(null);
    dispatch(setLoading(true));

    try {
      await cibilService.submitOtp(sessionId, otp);
      dispatch(setCurrentStep('EXTRACTING'));
      toast.success('OTP verified! Extracting your credit score...');
      return true;
    } catch (err: any) {
      const msg = err?.message ?? 'OTP verification failed.';
      setError(msg);
      toast.error(msg);
      return false;
    } finally {
      dispatch(setLoading(false));
    }
  }, [sessionId, dispatch]);

  return { submitOtp, otpError: error, clearOtpError: () => setError(null) };
};
