import { useEffect, useRef, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { AppDispatch } from '@/store/store';
import { setCurrentStep, setSessionStatus, setError } from '@/store/cibilSlice';
import { sessionService } from '@/services/sessionService';
import { SessionStatus } from '@/types/cibil.types';

const POLL_INTERVAL = Number(import.meta.env.VITE_SESSION_POLL_INTERVAL_MS) || 3000;

export const useSessionStatus = (
  sessionId: string | null,
  active: boolean,
  onOtpRequired: () => void,
  onCompleted: () => void
) => {
  const dispatch   = useDispatch<AppDispatch>();
  const intervalId = useRef<ReturnType<typeof setInterval> | null>(null);

  const stopPolling = useCallback(() => {
    if (intervalId.current) {
      clearInterval(intervalId.current);
      intervalId.current = null;
    }
  }, []);

  useEffect(() => {
    if (!sessionId || !active) {
      stopPolling();
      return;
    }

    const poll = async () => {
      try {
        const response = await sessionService.getStatus(sessionId);
        dispatch(setSessionStatus(response.status as SessionStatus));

        switch (response.status) {
          case 'OTP_AWAITED':
            stopPolling();
            onOtpRequired();
            break;
          case 'COMPLETED':
            stopPolling();
            onCompleted();
            break;
          case 'FAILED':
          case 'EXPIRED':
            stopPolling();
            dispatch(setError(response.errorMessage ?? 'Session failed. Please try again.'));
            break;
          case 'EXTRACTING':
            dispatch(setCurrentStep('EXTRACTING'));
            break;
          default:
            break;
        }
      } catch {
        // Silently retry on network errors
      }
    };

    poll(); // immediate first call
    intervalId.current = setInterval(poll, POLL_INTERVAL);

    return () => stopPolling();
  }, [sessionId, active, dispatch, onOtpRequired, onCompleted, stopPolling]);

  return { stopPolling };
};
