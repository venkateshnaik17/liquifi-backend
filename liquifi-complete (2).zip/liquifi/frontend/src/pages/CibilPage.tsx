import React, { useCallback, useState } from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@/store/store';
import { useCibilFlow }      from '@/hooks/useCibilFlow';
import { useSessionStatus }  from '@/hooks/useSessionStatus';
import CibilForm         from '@/components/cibil/CibilForm';
import OtpVerification   from '@/components/cibil/OtpVerification';
import Loader            from '@/components/common/Loader';
import { CibilFormData } from '@/types/cibil.types';

const STATUS_MESSAGES: Record<string, string> = {
  PENDING:          'Initializing your session...',
  BROWSER_LAUNCHED: 'Opening UrbanMoney portal...',
  FORM_FILLED:      'Form submitted. Waiting for OTP...',
  OTP_SUBMITTED:    'OTP verified! Extracting your score...',
  EXTRACTING:       'Fetching and analyzing your credit report...',
};

const CibilPage: React.FC = () => {
  const { state, submitForm, fetchResult, reset } = useCibilFlow();
  const [mobileNumber, setMobileNumber] = useState('');
  const sessionStatus = useSelector((s: RootState) => s.cibil.sessionStatus);

  const onOtpRequired = useCallback(() => {
    // currentStep set to OTP_AWAITED by useSessionStatus
  }, []);

  const onCompleted = useCallback(() => {
    fetchResult();
  }, [fetchResult]);

  const isPollingActive =
    state.currentStep === 'PROCESSING' || state.currentStep === 'EXTRACTING';

  useSessionStatus(state.sessionId, isPollingActive, onOtpRequired, onCompleted);

  const handleFormSubmit = async (data: CibilFormData) => {
    setMobileNumber(data.mobileNumber);
    await submitForm(data);
  };

  // ── FORM ──────────────────────────────────────────────────────
  if (state.currentStep === 'FORM') {
    return (
      <div>
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Check Your CIBIL Score</h2>
          <p className="text-gray-500 text-sm mt-1">
            Free, instant, and does not affect your credit score.
          </p>
        </div>
        <CibilForm onSubmit={handleFormSubmit} isLoading={state.isLoading} />
      </div>
    );
  }

  // ── OTP ───────────────────────────────────────────────────────
  if (state.currentStep === 'OTP' || sessionStatus === 'OTP_AWAITED') {
    return (
      <OtpVerification
        sessionId={state.sessionId!}
        mobile={mobileNumber}
        onSuccess={() => {/* polling handles next step */}}
      />
    );
  }

  // ── PROCESSING / EXTRACTING ───────────────────────────────────
  if (state.currentStep === 'PROCESSING' || state.currentStep === 'EXTRACTING') {
    const msg = sessionStatus ? STATUS_MESSAGES[sessionStatus] : 'Processing...';
    return <Loader message={msg} size="lg" fullPage />;
  }

  // ── ERROR ─────────────────────────────────────────────────────
  if (state.currentStep === 'ERROR') {
    return (
      <div className="text-center py-12 space-y-4">
        <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto">
          <span className="text-3xl">⚠️</span>
        </div>
        <h3 className="text-xl font-bold text-gray-900">Something went wrong</h3>
        <p className="text-gray-600 text-sm max-w-sm mx-auto">
          {state.errorMessage ?? 'An unexpected error occurred. Please try again.'}
        </p>
        <button
          onClick={reset}
          className="mt-4 text-indigo-600 hover:underline text-sm font-medium"
        >
          ← Try Again
        </button>
      </div>
    );
  }

  return null;
};

export default CibilPage;
