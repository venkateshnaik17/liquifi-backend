import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '@/store/store';
import { useCibilFlow } from '@/hooks/useCibilFlow';
import CibilResult from '@/components/cibil/CibilResult';
import Loader from '@/components/common/Loader';

const ResultPage: React.FC = () => {
  const result = useSelector((s: RootState) => s.cibil.result);
  const { reset } = useCibilFlow();

  if (!result) {
    return <Loader message="Loading your credit report..." fullPage />;
  }

  return <CibilResult result={result} onReset={reset} />;
};

export default ResultPage;
