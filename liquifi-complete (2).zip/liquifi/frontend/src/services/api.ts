import axios, { AxiosError, AxiosInstance } from 'axios';
import { ApiError } from '@/types/api.types';

const BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';

const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept':       'application/json',
  },
});

// Request interceptor
apiClient.interceptors.request.use(
  (config) => config,
  (error) => Promise.reject(error)
);

// Response interceptor — normalise errors
apiClient.interceptors.response.use(
  (response) => response,
  (error: AxiosError<ApiError>) => {
    const apiError: ApiError = {
      status:      error.response?.status ?? 0,
      error:       error.response?.data?.error ?? 'Network Error',
      message:     error.response?.data?.message ?? 'Something went wrong. Please try again.',
      timestamp:   new Date().toISOString(),
      fieldErrors: error.response?.data?.fieldErrors,
    };
    return Promise.reject(apiError);
  }
);

export default apiClient;
