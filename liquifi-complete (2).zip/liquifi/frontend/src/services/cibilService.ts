import apiClient from './api';
import { CibilFormData } from '@/types/cibil.types';
import { InitiateResponse, OtpSubmitResponse } from '@/types/api.types';

export const cibilService = {
  /**
   * Submits the CIBIL form data. Returns sessionId.
   */
  initiate: async (formData: CibilFormData): Promise<InitiateResponse> => {
    const { data } = await apiClient.post<InitiateResponse>('/cibil/initiate', {
      fullName:     formData.fullName.trim(),
      dob:          formData.dob,
      mobileNumber: formData.mobileNumber.trim(),
      email:        formData.email.trim().toLowerCase(),
      panCard:      formData.panCard.trim().toUpperCase(),
      consentGiven: formData.consentGiven,
    });
    return data;
  },

  /**
   * Submits the OTP entered by the user.
   * OTP is sent once and NOT stored permanently.
   */
  submitOtp: async (sessionId: string, otp: string): Promise<OtpSubmitResponse> => {
    const { data } = await apiClient.post<OtpSubmitResponse>('/otp/submit', {
      sessionId,
      otp: otp.trim(),
    });
    return data;
  },

  /**
   * Fetches the final CIBIL result once session is COMPLETED.
   */
  getResult: async (sessionId: string) => {
    const { data } = await apiClient.get(`/cibil/result/${sessionId}`);
    return data;
  },
};
