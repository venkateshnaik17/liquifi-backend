import apiClient from './api';
import { SessionStatusResponse } from '@/types/cibil.types';

export const sessionService = {
  getStatus: async (sessionId: string): Promise<SessionStatusResponse> => {
    const { data } = await apiClient.get<SessionStatusResponse>(
      `/session/status/${sessionId}`
    );
    return data;
  },
};
