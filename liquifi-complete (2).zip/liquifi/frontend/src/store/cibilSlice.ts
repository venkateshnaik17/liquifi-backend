import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CibilFlowStep, CibilResult, SessionStatus } from '@/types/cibil.types';

interface CibilState {
  sessionId:     string | null;
  currentStep:   CibilFlowStep;
  sessionStatus: SessionStatus | null;
  result:        CibilResult | null;
  errorMessage:  string | null;
  isLoading:     boolean;
}

const initialState: CibilState = {
  sessionId:     null,
  currentStep:   'FORM',
  sessionStatus: null,
  result:        null,
  errorMessage:  null,
  isLoading:     false,
};

const cibilSlice = createSlice({
  name: 'cibil',
  initialState,
  reducers: {
    setLoading(state, action: PayloadAction<boolean>) {
      state.isLoading = action.payload;
    },
    setSessionId(state, action: PayloadAction<string>) {
      state.sessionId = action.payload;
    },
    setCurrentStep(state, action: PayloadAction<CibilFlowStep>) {
      state.currentStep = action.payload;
    },
    setSessionStatus(state, action: PayloadAction<SessionStatus>) {
      state.sessionStatus = action.payload;
    },
    setResult(state, action: PayloadAction<CibilResult>) {
      state.result        = action.payload;
      state.currentStep   = 'RESULT';
    },
    setError(state, action: PayloadAction<string>) {
      state.errorMessage = action.payload;
      state.currentStep  = 'ERROR';
      state.isLoading    = false;
    },
    resetFlow(state) {
      Object.assign(state, initialState);
    },
  },
});

export const {
  setLoading,
  setSessionId,
  setCurrentStep,
  setSessionStatus,
  setResult,
  setError,
  resetFlow,
} = cibilSlice.actions;

export default cibilSlice.reducer;
