import { configureStore } from '@reduxjs/toolkit';
import cibilReducer from './cibilSlice';

export const store = configureStore({
  reducer: {
    cibil: cibilReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({ serializableCheck: false }),
});

export type RootState   = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
