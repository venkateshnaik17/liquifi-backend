export interface ApiResponse<T> {
  data:    T;
  status:  number;
  message: string;
}

export interface ApiError {
  status:      number;
  error:       string;
  message:     string;
  timestamp:   string;
  fieldErrors?: Record<string, string>;
}

export interface InitiateResponse {
  sessionId: string;
  message:   string;
}

export interface OtpSubmitResponse {
  message: string;
}
