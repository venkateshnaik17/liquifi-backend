export interface CibilFormData {
  fullName: string;
  dob: string;
  mobileNumber: string;
  email: string;
  panCard: string;
  consentGiven: boolean;
}

export interface CreditSummary {
  totalAccounts:    number | null;
  activeAccounts:   number | null;
  closedAccounts:   number | null;
  overdueAccounts:  number | null;
  totalCreditLimit: number | null;
  totalBalance:     number | null;
}

export interface LoanEligibility {
  loanType:         string;
  maxAmount:        string | null;
  interestRate:     string | null;
  tenure:           string | null;
  eligibilityStatus: 'ELIGIBLE' | 'NOT_ELIGIBLE' | 'PRE_APPROVED' | 'UNKNOWN';
  rawText?:         string;
}

export interface CibilResult {
  sessionId:       string;
  fullName:        string;
  creditScore:     number | null;
  scoreBand:       'EXCELLENT' | 'GOOD' | 'FAIR' | 'POOR' | null;
  scoreAsOfDate:   string | null;
  creditSummary:   CreditSummary | null;
  loanEligibility: LoanEligibility[];
  extractedAt:     string;
}

export type SessionStatus =
  | 'PENDING'
  | 'BROWSER_LAUNCHED'
  | 'FORM_FILLED'
  | 'OTP_AWAITED'
  | 'OTP_SUBMITTED'
  | 'EXTRACTING'
  | 'COMPLETED'
  | 'FAILED'
  | 'EXPIRED';

export interface SessionStatusResponse {
  sessionId:    string;
  status:       SessionStatus;
  errorMessage: string | null;
  resultReady:  boolean;
}

export type CibilFlowStep =
  | 'FORM'
  | 'CONSENT'
  | 'PROCESSING'
  | 'OTP'
  | 'EXTRACTING'
  | 'RESULT'
  | 'ERROR';
