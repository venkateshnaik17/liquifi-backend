export const formatCurrency = (amount: number | null | undefined): string => {
  if (amount == null) return 'N/A';
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`;
  if (amount >= 100000)   return `₹${(amount / 100000).toFixed(2)} L`;
  return `₹${amount.toLocaleString('en-IN')}`;
};

export const formatDate = (dateStr: string | null | undefined): string => {
  if (!dateStr) return 'N/A';
  return new Date(dateStr).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
};

export const maskMobile = (mobile: string): string => {
  if (!mobile || mobile.length < 4) return '****';
  return mobile.slice(0, 2) + 'XXXXXX' + mobile.slice(-2);
};

export const maskPan = (pan: string): string => {
  if (!pan || pan.length < 4) return '****';
  return 'XXXXX' + pan.slice(5, 9) + 'X';
};

export const getScoreBandColor = (band: string | null): string => {
  switch (band) {
    case 'EXCELLENT': return 'text-green-600';
    case 'GOOD':      return 'text-blue-600';
    case 'FAIR':      return 'text-yellow-600';
    case 'POOR':      return 'text-red-600';
    default:          return 'text-gray-600';
  }
};

export const getScoreBandBg = (band: string | null): string => {
  switch (band) {
    case 'EXCELLENT': return 'bg-green-100 border-green-300';
    case 'GOOD':      return 'bg-blue-100 border-blue-300';
    case 'FAIR':      return 'bg-yellow-100 border-yellow-300';
    case 'POOR':      return 'bg-red-100 border-red-300';
    default:          return 'bg-gray-100 border-gray-300';
  }
};

export const getScoreArcDegrees = (score: number | null): number => {
  if (!score) return 0;
  const min = 300, max = 900;
  return Math.round(((score - min) / (max - min)) * 180);
};
