import { z } from 'zod';

export const cibilFormSchema = z.object({
  fullName: z
    .string()
    .min(2, 'Full name must be at least 2 characters')
    .max(255, 'Full name is too long')
    .regex(/^[a-zA-Z\s.'-]+$/, 'Full name contains invalid characters'),

  dob: z
    .string()
    .min(1, 'Date of birth is required')
    .refine((val) => {
      const date = new Date(val);
      return date < new Date() && !isNaN(date.getTime());
    }, 'Date of birth must be a valid past date'),

  mobileNumber: z
    .string()
    .regex(/^[6-9]\d{9}$/, 'Enter a valid 10-digit Indian mobile number'),

  email: z
    .string()
    .email('Enter a valid email address')
    .max(255),

  panCard: z
    .string()
    .regex(/^[A-Z]{5}[0-9]{4}[A-Z]$/, 'Enter a valid PAN (e.g. ABCDE1234F)')
    .transform((val) => val.toUpperCase()),

  consentGiven: z
    .boolean()
    .refine((val) => val === true, 'You must accept the consent to proceed'),
});

export type CibilFormSchema = z.infer<typeof cibilFormSchema>;

export const otpSchema = z.object({
  otp: z
    .string()
    .min(4, 'OTP must be at least 4 digits')
    .max(8, 'OTP cannot exceed 8 digits')
    .regex(/^\d+$/, 'OTP must contain only digits'),
});

export type OtpSchema = z.infer<typeof otpSchema>;
