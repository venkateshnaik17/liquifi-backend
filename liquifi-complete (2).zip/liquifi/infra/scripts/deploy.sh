#!/usr/bin/env bash
set -euo pipefail

# ─── LiquiFi Production Deploy Script ─────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

echo "🚀 [LiquiFi Deploy] Starting deployment..."
echo "   Project root: $PROJECT_ROOT"

# 1. Pull latest
echo "📥 Pulling latest code..."
cd "$PROJECT_ROOT"
git pull origin main

# 2. Build frontend
echo "🔨 Building frontend..."
cd "$PROJECT_ROOT/frontend"
npm ci --silent
npm run build
echo "✅ Frontend built → dist/"

# 3. Build backend docker image
echo "🐳 Building backend Docker image..."
cd "$PROJECT_ROOT/infra/docker"
docker compose build --no-cache backend

# 4. Build automation docker image
echo "🤖 Building automation Docker image..."
docker compose build --no-cache automation

# 5. Rolling restart — backend first
echo "🔄 Restarting backend..."
docker compose up -d --no-deps backend
sleep 10

# 6. Health check backend
echo "🏥 Health checking backend..."
for i in {1..12}; do
  if curl -sf http://localhost:8080/api/actuator/health > /dev/null; then
    echo "✅ Backend healthy"
    break
  fi
  echo "   Waiting... ($i/12)"
  sleep 5
done

# 7. Restart automation worker
echo "🔄 Restarting automation worker..."
docker compose up -d --no-deps automation

# 8. Reload nginx
echo "🔄 Reloading NGINX..."
docker compose restart frontend
nginx -t && systemctl reload nginx 2>/dev/null || true

echo ""
echo "✅ Deployment complete!"
docker compose ps
