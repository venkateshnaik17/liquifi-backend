#!/usr/bin/env bash
set -euo pipefail

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  LiquiFi System Health Check"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# Backend
printf "Backend API:   "
if curl -sf http://localhost:8080/api/actuator/health | grep -q '"status":"UP"'; then
  echo "✅ UP"
else
  echo "❌ DOWN"
fi

# Redis
printf "Redis:         "
if docker exec liquifi-redis redis-cli ping | grep -q PONG; then
  echo "✅ UP"
else
  echo "❌ DOWN"
fi

# Automation
printf "Automation:    "
if docker ps --filter name=liquifi-automation --filter status=running | grep -q automation; then
  echo "✅ RUNNING"
else
  echo "❌ NOT RUNNING"
fi

# Nginx
printf "NGINX:         "
if systemctl is-active --quiet nginx 2>/dev/null || \
   docker ps --filter name=liquifi-frontend --filter status=running | grep -q frontend; then
  echo "✅ UP"
else
  echo "❌ DOWN"
fi

echo ""
echo "Docker containers:"
docker compose -f "$(dirname "$0")/../docker/docker-compose.yml" ps
