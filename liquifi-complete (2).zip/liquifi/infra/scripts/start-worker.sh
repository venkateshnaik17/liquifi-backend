#!/usr/bin/env bash
set -euo pipefail

echo "🤖 Starting LiquiFi Automation Worker..."
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../../infra/docker"

docker compose up -d automation
echo "✅ Automation worker started. Logs:"
docker compose logs -f automation
