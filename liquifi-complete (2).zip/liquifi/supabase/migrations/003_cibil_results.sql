-- =============================================================
-- Migration: 003 - CIBIL Results
-- =============================================================

CREATE TABLE cibil_results (
    id                      UUID          PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id              VARCHAR(64)   NOT NULL UNIQUE,
    mobile_number           VARCHAR(15)   NOT NULL,
    pan_card                VARCHAR(10)   NOT NULL,
    full_name               VARCHAR(255)  NOT NULL,

    -- Credit Score
    credit_score            INT,
    score_band              VARCHAR(50),   -- EXCELLENT / GOOD / FAIR / POOR
    score_as_of_date        DATE,

    -- Credit Summary (JSON blob for flexibility)
    credit_summary          JSONB,

    -- Loan Eligibility (JSON blob)
    loan_eligibility        JSONB,

    -- Raw HTML snapshot for audit / re-parsing
    raw_html_snapshot       TEXT,

    -- Screenshot path on VPS disk
    screenshot_path         VARCHAR(512),

    extracted_at            TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    created_at              TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_cibil_results_session_id    ON cibil_results(session_id);
CREATE INDEX idx_cibil_results_pan_card      ON cibil_results(pan_card);
CREATE INDEX idx_cibil_results_mobile        ON cibil_results(mobile_number);
CREATE INDEX idx_cibil_results_credit_score  ON cibil_results(credit_score DESC);
CREATE INDEX idx_cibil_results_created_at    ON cibil_results(created_at DESC);
CREATE INDEX idx_cibil_results_summary_gin   ON cibil_results USING GIN (credit_summary);
CREATE INDEX idx_cibil_results_eligiblity_gin ON cibil_results USING GIN (loan_eligibility);

COMMENT ON TABLE  cibil_results                  IS 'Stores extracted CIBIL credit data per automation session';
COMMENT ON COLUMN cibil_results.credit_summary   IS 'JSON: {totalAccounts, activeAccounts, closedAccounts, overdueAccounts, totalCreditLimit, totalBalance, totalOverdue}';
COMMENT ON COLUMN cibil_results.loan_eligibility IS 'JSON array of {loanType, maxAmount, interestRate, tenure, eligibilityStatus}';
COMMENT ON COLUMN cibil_results.raw_html_snapshot IS 'Stored for auditing and re-extraction without re-running browser';
