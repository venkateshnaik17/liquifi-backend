-- =============================================================
-- Seed: Development test data
-- WARNING: Never run in production
-- =============================================================

INSERT INTO consent_logs (
    session_id, full_name, dob, mobile_number, email, pan_card,
    consent_text, consent_given, ip_address
) VALUES (
    'test-session-001',
    'Ravi Kumar',
    '1990-05-15',
    '9876543210',
    'ravi.kumar@example.com',
    'ABCDE1234F',
    'I agree to the Terms and Conditions of TUCIBIL and hereby provide explicit consent to share my Credit Information with Urban Money Private Limited.',
    TRUE,
    '127.0.0.1'
);

INSERT INTO cibil_sessions (
    session_id, full_name, dob, mobile_number, email, pan_card, status
) VALUES (
    'test-session-001',
    'Ravi Kumar',
    '1990-05-15',
    '9876543210',
    'ravi.kumar@example.com',
    'ABCDE1234F',
    'COMPLETED'
);

INSERT INTO cibil_results (
    session_id, mobile_number, pan_card, full_name,
    credit_score, score_band, score_as_of_date,
    credit_summary, loan_eligibility
) VALUES (
    'test-session-001',
    '9876543210',
    'ABCDE1234F',
    'Ravi Kumar',
    742,
    'GOOD',
    '2024-12-01',
    '{"totalAccounts": 5, "activeAccounts": 3, "closedAccounts": 2, "overdueAccounts": 0, "totalCreditLimit": 500000, "totalBalance": 120000, "totalOverdue": 0}',
    '[{"loanType": "Personal Loan", "maxAmount": 500000, "interestRate": "10.5%", "tenure": "60 months", "eligibilityStatus": "ELIGIBLE"}, {"loanType": "Home Loan", "maxAmount": 5000000, "interestRate": "8.5%", "tenure": "240 months", "eligibilityStatus": "ELIGIBLE"}]'
);
